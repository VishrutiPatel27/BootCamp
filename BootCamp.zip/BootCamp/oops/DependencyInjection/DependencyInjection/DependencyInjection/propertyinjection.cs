﻿namespace dependencyinjection
{
    internal class propertyinjection
    {
        public propertyinjection()
        {
        }
    }
}